package com.canera1;
import java.util.ArrayList;
import java.util.Scanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

class Data {
    private int camera_id;
    private String brand;
    private String model;
    private double price;
    private boolean status;

    Data(int camera_id, String brand, String model, double price, boolean available) {
        this.camera_id = camera_id;
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.status = available;
    }

    public int getId() {
        return camera_id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return status;
    }

    public void setAvailable(boolean available) {
        this.status = available;
    }
}

@SpringBootApplication
public class CameraRental1Application {

	public static void main(String[] args) {
		SpringApplication.run(CameraRental1Application.class, args);
        System.out.println("----------------------------------------");
        System.out.println("WELCOME TO MY CAMERA RENTAL APPLICATION");
        System.out.println("----------------------------------------");

        double INR = 5000;
        String username, password;

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: "); // username: Silpa
        username = scanner.nextLine();
        System.out.print("Enter password: "); // password: 12345
        password = scanner.nextLine();

        if (username.equals("Silpa") && password.equals("12345")) {
            System.out.println("Login Successful");
            ArrayList<Data> list = new ArrayList<>();
            list.add(new Data(1, "Canon", "DSLR", 5000, true));
            list.add(new Data(2, "Sony", "Ds123", 1500, true));
            list.add(new Data(3, "Lenova", "XPL", 1300, true));
            list.add(new Data(4, "Nikon", "SRL", 5000, true));
            list.add(new Data(5, "Samsung", "DL", 350, true));
            list.add(new Data(6, "Gopro", "Go267", 3200, true));

            int continueFlag;
            do {
                int option;
                System.out.println("1. MY CAMERA");
                System.out.println("2. RENT A CAMERA");
                System.out.println("3. VIEW ALL CAMERAS");
                System.out.println("4. MY WALLET");
                System.out.println("5. Exit");
                System.out.print("Select your option: ");
                option = scanner.nextInt();

                switch (option) {
                    case 1:
                        int k = 0;
                        do {
                            System.out.println("1. ADD");
                            System.out.println("2. REMOVE");
                            System.out.println("3. VIEW MY CAMERAS");
                            System.out.println("4. GO TO PREVIOUS MENU");
                            System.out.print("Enter your choice: ");
                            int choose = scanner.nextInt();

                            switch (choose) {
                                case 1:
                                    System.out.print("Enter Camera ID: ");
                                    int camera_id = scanner.nextInt();
                                    System.out.print("Enter Camera Brand: ");
                                    String brand = scanner.next();
                                    System.out.print("Enter Camera Model: ");
                                    String model = scanner.next();
                                    System.out.print("Enter Camera Price per day: ");
                                    double price = scanner.nextDouble();
                                    boolean available = true;
                                    list.add(new Data(camera_id, brand, model, price, available));
                                    System.out.println("Successfully Added");
                                    System.out.print("Do you want to view the camera list? Enter '1' for Yes, '0' for No: ");
                                    int m = scanner.nextInt();
                                    if (m == 1) {
                                        System.out.println("cameraID\t Brand\t Model\t Price\t Status");
                                        for (Data data : list) {
                                            String status = data.isAvailable() ? "Available" : "Rented";
                                            System.out.println(data.getId() + "\t\t" + data.getBrand() + "\t" + data.getModel() +
                                                    "\t" + data.getPrice() + "\t" + status);
                                        }
                                    }
                                    break;

                                case 2:
                                    System.out.print("Which camera do you want to remove? (Enter camera ID): ");
                                    int cameraId = scanner.nextInt();
                                    list.removeIf(camera -> camera.getId() == cameraId);
                                    System.out.println("Camera removed if it existed.");
                                    break;

                                case 3:
                                    System.out.println("cameraID\t Brand\t Model\t Price\t Status");
                                    for (Data data : list) {
                                        String status = data.isAvailable() ? "Available" : "Rented";
                                        System.out.println(data.getId() + "\t\t" + data.getBrand() + "\t" + data.getModel() +
                                                "\t" + data.getPrice() + "\t" + status);
                                    }
                                    break;

                                case 4:
                                    k = 1;
                                    break;
                            }
                            System.out.print("Do you want to add or remove cameras? (1 for Yes, 0 for No): ");
                            k = scanner.nextInt();
                        } while (k == 1);
                        break;

                    case 2:
                        System.out.println("Available Cameras:");
                        for (Data data : list) {
                            if (data.isAvailable()) {
                                System.out.println(data.getId() + "\t\t" + data.getBrand() + "\t" + data.getModel() +
                                        "\t" + data.getPrice());
                            }
                        }
                        System.out.print("Which camera do you want to rent? (Enter camera ID): ");
                        int rentCameraId = scanner.nextInt();
                        Data rentedCamera = list.stream()
                                .filter(camera -> camera.getId() == rentCameraId)
                                .findFirst()
                                .orElse(null);

                        if (rentedCamera != null && rentedCamera.isAvailable()) {
                            if (rentedCamera.getPrice() <= INR) {
                                rentedCamera.setAvailable(false);
                                INR -= rentedCamera.getPrice();
                                System.out.println("Rented Successfully. Current wallet balance: " + INR);
                            } else {
                                System.out.println("You don't have sufficient balance in your wallet.");
                            }
                        } else {
                            System.out.println("Camera with ID " + rentCameraId + " is not available.");
                        }
                        break;

                    case 3:
                        System.out.println("cameraID\t Brand\t Model\t Price\t Status");
                        for (Data data : list) {
                            String status = data.isAvailable() ? "Available" : "Rented";
                            System.out.println(data.getId() + "\t\t" + data.getBrand() + "\t" + data.getModel() +
                                    "\t" + data.getPrice() + "\t" + status);
                        }
                        break;

                    case 4:
                        System.out.println("Your current wallet balance is: " + INR);
                        System.out.print("Do you want to deposit more amount to your wallet? (1 for Yes, 2 for No): ");
                        int depositOption = scanner.nextInt();
                        if (depositOption == 1) {
                            System.out.print("Enter deposit amount: ");
                            double addAmount = scanner.nextDouble();
                            INR += addAmount;
                            System.out.println("Your wallet balance updated successfully.");
                        }
                        System.out.println("Current wallet balance: " + INR);
                        break;
                }
                System.out.print("Do you want to continue? (1 for Yes, 2 for No): ");
                continueFlag = scanner.nextInt();
            } while (continueFlag == 1);
        } else {
            System.out.println("Authentication Failed");
        }

        System.out.println("Thank you for visiting the CAMERA RENTAL APPLICATION");
        scanner.close();
	}

	
	}


